package demopackage;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JPanel;
import javax.swing.Timer;

public class GamePlay extends JPanel implements ActionListener, KeyListener {

    private boolean play = true;
    private int score = 0;
    private int totalBrick = 21;

    private Timer timer;
    private int delay = 8;

    private int ballposX = 120;
    private int ballposY = 350;
    private int ballXdir = -1;
    private int ballYdir = -2;

    private int playerX = 310;

    public MapGenerator map;

    public GamePlay() {

        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        addKeyListener(this);

        map = new MapGenerator(3, 7);

        timer = new Timer(delay, this);
        timer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // background
        g.setColor(Color.black);
        g.fillRect(1, 1, 692, 592);

        // borders
        g.setColor(Color.yellow);
        g.fillRect(0, 0, 692, 3);
        g.fillRect(0, 3, 3, 592);
        g.fillRect(691, 3, 3, 592);

        // paddle
        g.setColor(Color.green);
        g.fillRect(playerX, 550, 100, 8);

        // bricks
        map.draw((Graphics2D) g);

        // ball
        g.setColor(Color.red);
        g.fillOval(ballposX, ballposY, 20, 20);

        // score
        g.setColor(Color.green);
        g.setFont(new Font("serif", Font.BOLD, 20));
        g.drawString("Score : " + score, 550, 30);

        // game over
        if (ballposY >= 570) {
            play = false;
            ballXdir = 0;
            ballYdir = 0;

            g.setColor(Color.green);
            g.setFont(new Font("serif", Font.BOLD, 30));
            g.drawString("GameOver!! Score: " + score, 200, 300);

            g.setFont(new Font("serif", Font.BOLD, 25));
            g.drawString("Press Enter to Restart", 230, 350);
        }

        // game win
        if (totalBrick <= 0) {
            play = false;
            ballXdir = 0;
            ballYdir = 0;

            g.setColor(Color.green);
            g.setFont(new Font("serif", Font.BOLD, 30));
            g.drawString("You Won!! Score: " + score, 200, 300);

            g.setFont(new Font("serif", Font.BOLD, 25));
            g.drawString("Press Enter to Restart", 230, 350);
        }
    }

    // 🔥 Increase ball speed every 5 bricks
    private void increaseBallSpeed() {
        if (ballXdir > 0) ballXdir++;
        else ballXdir--;

        if (ballYdir > 0) ballYdir++;
        else ballYdir--;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (play) {

            ballposX += ballXdir;
            ballposY += ballYdir;

            // wall collisions
            if (ballposX <= 0) ballXdir = -ballXdir;
            if (ballposX >= 670) ballXdir = -ballXdir;
            if (ballposY <= 0) ballYdir = -ballYdir;

            Rectangle ballRect = new Rectangle(ballposX, ballposY, 20, 20);
            Rectangle paddleRect = new Rectangle(playerX, 550, 100, 8);

            if (ballRect.intersects(paddleRect)) {
                ballYdir = -ballYdir;
            }

            // brick collision loop
            A:
            for (int i = 0; i < map.map.length; i++) {
                for (int j = 0; j < map.map[i].length; j++) {

                    if (map.map[i][j] > 0) {

                        int brickX = 80 + j * map.brickWidth;
                        int brickY = 50 + i * map.brickHeight;
                        int bw = map.brickWidth;
                        int bh = map.brickHeight;

                        Rectangle brickRect = new Rectangle(brickX, brickY, bw, bh);

                        if (ballRect.intersects(brickRect)) {

                            map.setBrick(0, i, j);
                            totalBrick--;
                            score += 5;

                            // ⭐ NEW FEATURE: speed increases every 5 bricks
                            if (score % 25 == 0) {
                                increaseBallSpeed();
                            }

                            if (ballposX + 19 <= brickX || ballposX + 1 >= brickX + bw)
                                ballXdir = -ballXdir;
                            else
                                ballYdir = -ballYdir;

                            break A;
                        }
                    }
                }
            }
        }
        repaint();
    }

    @Override
    public void keyPressed(KeyEvent e) {

        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            playerX = Math.max(playerX - 20, 0);
        }

        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            playerX = Math.min(playerX + 20, 600);
        }

        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            if (!play) {
                play = true;
                ballposX = 120;
                ballposY = 350;
                ballXdir = -1;
                ballYdir = -2;
                playerX = 310;
                score = 0;
                totalBrick = 21;
                map = new MapGenerator(3, 7);
            }
        }

        repaint();
    }

    @Override public void keyReleased(KeyEvent e) {}
    @Override public void keyTyped(KeyEvent e) {}
}
