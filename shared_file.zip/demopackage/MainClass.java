package demopackage;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class MainClass {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame f = new JFrame();
            f.setTitle("Brick Breaker");
            f.setSize(700, 600);
            f.setLocationRelativeTo(null);
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            f.setResizable(false);

            GamePlay game = new GamePlay();
            f.add(game);

            f.setVisible(true);                 // make frame visible last
            game.requestFocusInWindow();        // give keyboard focus to the panel
        });
    }
}
