package demopackage;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;

public class MapGenerator {

    public int map[][];
    public int brickWidth;
    public int brickHeight;

    public MapGenerator(int row, int col) {

        map = new int[row][col];

        for (int i = 0; i < row; i++)
            for (int j = 0; j < col; j++)
                map[i][j] = 1; // brick visible

        brickWidth = 540 / col;
        brickHeight = 150 / row;
    }

    public void draw(Graphics2D g) {

        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[i].length; j++) {

                if (map[i][j] > 0) {
                    g.setColor(Color.white);
                    g.fillRect(80 + j * brickWidth, 50 + i * brickHeight, brickWidth, brickHeight);

                    g.setStroke(new BasicStroke(3));
                    g.setColor(Color.black);
                    g.drawRect(80 + j * brickWidth, 50 + i * brickHeight, brickWidth, brickHeight);
                }
            }
        }
    }

    public void setBrick(int value, int row, int col) {
        map[row][col] = value;
    }
}
